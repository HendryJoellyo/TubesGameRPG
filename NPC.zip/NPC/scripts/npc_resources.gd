class_name NPCResources extends Resource


@export var npc_name : String = ""
@export var sprite : Texture 
@export var portrait : Texture
@export var dialog_audio_pitch : String
